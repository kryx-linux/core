# automatically generated file - see ../scripts/reversion
EXIM_RELEASE_VERSION="4.96.1"
EXIM_COMPILE_NUMBER="1"
